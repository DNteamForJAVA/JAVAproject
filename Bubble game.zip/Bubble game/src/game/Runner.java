package game;

public class Runner {
    public static void main(String args[]){
        MainUI ui = new MainUI();
    }
}
